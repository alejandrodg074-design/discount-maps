# Discount Maps

Subscription platform that connects consumers ("Persona") with local merchants ("Empresa") publishing exclusive coupons on category-filtered interactive maps. Consumers show a rotating QR at the store; merchants scan it to confirm the subscription is active.

## App

One mobile-first installable PWA, `apps/web` (Nx project `web`), built with Next.js 16 on Supabase, Wompi (Colombia) and Google Maps. Every account has one role and one login (`/login`); routing sends each role to its own area:

| Area    | Audience                                               | Routes                                                       |
| ------- | ------------------------------------------------------ | ------------------------------------------------------------ |
| Persona | Consumers: maps, business profiles, coupon QR, account | `/mapas`, `/negocios/*`, `/cuenta`, `/contacto`, `/registro` |
| Empresa | Merchants: onboarding, coupon management, QR scanner   | `/empresa`, `/empresa/*`                                     |
| Admin   | Business verification                                  | `/admin`                                                     |

Shared code lives in `packages/*` as `@org/*` workspace packages.

## Plan, progress and knowledge base

The full architecture, database schema, business rules and phased roadmap live in [docs/mvp-plan.md](docs/mvp-plan.md). The checklist at the top of that file is the source of truth for implementation progress. Working conventions and workflows are indexed by task in [AGENTS.md](AGENTS.md).

## Working with the AI (no coding required)

The repo is set up so a non-technical owner can keep iterating through Claude Code. Read [docs/owner-guide.md](docs/owner-guide.md) (Spanish) for how to ask, review, approve and undo changes. Agents follow [docs/agent-protocol.md](docs/agent-protocol.md) and the task catalogue in [docs/recipes.md](docs/recipes.md); slash commands `/owner-request`, `/ship`, `/verify`, `/status` and `/undo` live in `.claude/skills/`, and `scripts/agent-guard.mjs` blocks destructive commands.

## Common commands

```sh
pnpm install
pnpm nx run-many -t lint typecheck test build
pnpm nx dev web
```

Local database (requires Docker): `pnpm db:start`, `pnpm db:reset`, `pnpm db:types`, `pnpm db:test`.
